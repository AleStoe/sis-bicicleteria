import { formatNumber } from "../../utils/formatters";
import { getEstadoStock } from "../../utils/stockUtils";

export default function StockTable({
  stockFiltrado,
  seleccionado,
  seleccionarItem,
  styles,
  EstadoBadge,
}) {
  return (
    <table style={styles.table}>
      <thead style={styles.thead}>
        <tr>
          <th style={styles.th}>Producto</th>
          <th style={styles.th}>Sucursal</th>
          <th style={styles.thNumber}>Físico</th>
          <th style={styles.thNumber}>Reservado</th>
          <th style={styles.thNumber}>Pendiente</th>
          <th style={styles.thNumber}>Disponible</th>
          <th style={styles.th}>Estado</th>
          <th style={styles.th}>Acciones</th>
        </tr>
      </thead>

      <tbody>
        {stockFiltrado.map((item) => {
          const estado = getEstadoStock(item);
          const activo =
            seleccionado?.variante_id === item.variante_id &&
            seleccionado?.sucursal_id === item.sucursal_id;

          return (
            <tr
              key={`${item.sucursal_id}-${item.variante_id}`}
              onClick={() => seleccionarItem(item, "detalle")}
              style={activo ? styles.trActive : styles.tr}
            >
              <td style={styles.tdProduct}>
                <strong style={styles.productName}>{item.producto_nombre}</strong>
                <div style={styles.variantName}>{item.nombre_variante}</div>
                <div style={styles.mutedSmall}>
                  SKU: {item.sku || "-"} · Variante #{item.variante_id}
                </div>
              </td>

              <td style={styles.td}>{item.sucursal_nombre}</td>

              <td style={styles.tdNumber}>{formatNumber(item.stock_fisico)}</td>
              <td style={styles.tdNumber}>{formatNumber(item.stock_reservado)}</td>
              <td style={styles.tdNumber}>
                {formatNumber(item.stock_vendido_pendiente_entrega)}
              </td>
              <td style={styles.tdNumberStrong}>
                {formatNumber(item.stock_disponible)}
              </td>

              <td style={styles.td}>
                <EstadoBadge estado={estado} />
              </td>

              <td style={styles.td}>
                <div style={styles.rowActions}>
                  <button
                    type="button"
                    style={styles.actionButton}
                    onClick={(e) => {
                      e.stopPropagation();
                      seleccionarItem(item, "ingreso");
                    }}
                  >
                    Ingreso
                  </button>

                  <button
                    type="button"
                    style={styles.dangerOutlineButton}
                    onClick={(e) => {
                      e.stopPropagation();
                      seleccionarItem(item, "ajuste");
                    }}
                  >
                    Ajuste
                  </button>
                </div>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
